package com.example.tp2javafx;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage)  {



        //creation du BorderPane
        BorderPane layout = new BorderPane();



        //creation des radio button
        RadioButton de2 = new RadioButton("2");
        RadioButton de4 = new RadioButton("4");
        RadioButton de6 = new RadioButton("6");
        RadioButton de8 = new RadioButton("8");
        RadioButton de10 = new RadioButton("10");
        RadioButton de12 = new RadioButton("12");
        RadioButton de20 = new RadioButton("20");
        RadioButton de100 = new RadioButton("100");




        //creation de differents labels
        Label RollTheDice = new Label("Roll the dice");
        Label Tirages = new Label("tirages");
        Label Resultat = new Label("0");


        //creation des boutons
        Button Roll = new Button("Roll");
        Button end = new Button("end");


        //creation de la hbox qui contiendra les radio button
        HBox hbox = new HBox();
        hbox.getChildren().addAll(de2, de4, de6, de8, de10, de12, de20, de100);

        //creation de la Hbox qui contiendra les boutons
        HBox hboxBoutons = new HBox();
        hboxBoutons.getChildren().addAll(Roll, end);

        //creation du ToggleGroup pour les radio button
        ToggleGroup group = new ToggleGroup();
        de2.setToggleGroup(group);
        de4.setToggleGroup(group);
        de6.setToggleGroup(group);
        de8.setToggleGroup(group);
        de10.setToggleGroup(group);
        de12.setToggleGroup(group);
        de20.setToggleGroup(group);
        de100.setToggleGroup(group);



        //ajout de la hbox au BorderPane en haut
        layout.setTop(hbox);

        //ajout de la hboxBoutons au BorderPane en bas
        layout.setBottom(hboxBoutons);


        //ajout des labels au BorderPane a gauche
        layout.setLeft(RollTheDice);

        //ajout des labels au BorderPane a droite
        layout.setRight(Tirages);

        //ajout des labels au BorderPane au centre
        layout.setCenter(Resultat);

        //aligner a gauche le label de droite
        layout.setAlignment(Tirages, Pos.TOP_LEFT);


        //aligner les hbox  au centre
        hboxBoutons.setAlignment( Pos.CENTER);
        hbox.setAlignment(Pos.CENTER);


        //ajout des espaces entre les radio button
        hbox.setSpacing(10);

        //ajout des espaces entre et en dessus et dessous des boutons
        hboxBoutons.setPadding(new javafx.geometry.Insets(10, 10, 10, 10));


        //changer la police des labels
        Resultat.setStyle("-fx-font: 24 arial;");

        //changer le label de gauche selon le radio button selectioné
        de2.setOnAction(e -> RollTheDice.setText("Roll the 2 dice"));
        de4.setOnAction(e -> RollTheDice.setText("Roll the 4 dice"));
        de6.setOnAction(e -> RollTheDice.setText("Roll the 6 dice"));
        de8.setOnAction(e -> RollTheDice.setText("Roll the 8 dice"));
        de10.setOnAction(e -> RollTheDice.setText("Roll the 10 dice"));
        de12.setOnAction(e -> RollTheDice.setText("Roll the 12 dice"));
        de20.setOnAction(e -> RollTheDice.setText("Roll the 20 dice"));
        de100.setOnAction(e -> RollTheDice.setText("Roll the 100 dice"));

        //changer le label de droite selon le resultat du de
        Roll.setOnAction(e -> Tirages.setText("tirages : " + Resultat.getText()));




        //lancer le de avec la ligne math.random grace au bouton roll selon le radio button selectioné
        Roll.setOnAction(e -> Resultat.setText(String.valueOf((int) (Math.random() * 2))));
        Roll.setOnAction(e -> Resultat.setText(String.valueOf((int) (Math.random() * 4))));
        Roll.setOnAction(e -> Resultat.setText(String.valueOf((int) (Math.random() * 6))));
        Roll.setOnAction(e -> Resultat.setText(String.valueOf((int) (Math.random() * 8))));
        Roll.setOnAction(e -> Resultat.setText(String.valueOf((int) (Math.random() * 10))));
        Roll.setOnAction(e -> Resultat.setText(String.valueOf((int) (Math.random() * 12))));
        Roll.setOnAction(e -> Resultat.setText(String.valueOf((int) (Math.random() * 20))));
        Roll.setOnAction(e -> Resultat.setText(String.valueOf((int) (Math.random() * 100))));


//reset le libele central a chaque fois que l'on clique sur un radio button
        de2.setOnAction(e -> Resultat.setText("0"));
        de4.setOnAction(e -> Resultat.setText("0"));
        de6.setOnAction(e -> Resultat.setText("0"));
        de8.setOnAction(e -> Resultat.setText("0"));
        de10.setOnAction(e -> Resultat.setText("0"));
        de12.setOnAction(e -> Resultat.setText("0"));
        de20.setOnAction(e -> Resultat.setText("0"));
        de100.setOnAction(e -> Resultat.setText("0"));


        //Creation de la scene
        Scene scene = new Scene(layout, 600, 450);


        //Affichage de la scene
        stage.setTitle("Application Newsletter");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}