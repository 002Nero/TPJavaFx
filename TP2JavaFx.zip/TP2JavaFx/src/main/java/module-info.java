module com.example.tp2javafx {
    requires javafx.controls;
    requires javafx.fxml;
            
                            
    opens com.example.tp2javafx to javafx.fxml;
    exports com.example.tp2javafx;
}